

setInterval(main, 1000/60); 


function main()
{   
        
        if(gamemode===1)       {
                start=0;
                About=0;
        enemy1.EnMov();
        player.hasCollided();
        
}
}